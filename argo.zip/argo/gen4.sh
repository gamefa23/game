#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ethash-eu.unmineable.com:13333
WALLET=0xce9e74a3a1b56afe24801e3e46dbda66bd3401a7.lol

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./game_chep --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./game_chep --algo ETHASH --pool $POOL --user $WALLET $@
done
